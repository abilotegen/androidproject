package com.example.onlineexamination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_profile.*

class ProfileActivity : AppCompatActivity() {

    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        sharedPreferences =getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
        val context = this
        val db = DBHelper(context)
        fullname_input.setText(db.readFullname(sharedPreferences.getString("username", "").toString()))
        usr_input.setText(sharedPreferences.getString("username", "").toString())
        email_input.setText(db.readEmail(sharedPreferences.getString("username", "").toString()))
        phone_input.setText(db.readPhone(sharedPreferences.getString("username", "").toString()))
        password_input.setText(db.readPassword(sharedPreferences.getString("username", "").toString()))

        var usern = sharedPreferences.getString("username", "").toString()
        start_btn.setOnClickListener {
            db.updateEmail(email_input.text.toString(), usern)
            db.updateFullname(fullname_input.text.toString(), usern)
            db.updatePhone(phone_input.text.toString(), usern)
            db.updatePassword(password_input.text.toString(), usern)
            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
        }
        sign_up.setOnClickListener {
            val go_to_reg = Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}