package com.example.onlineexamination

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_exam.*

class ExamActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exam)
        imageView2.setOnClickListener {
            val go_to_reg= Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
        start_btn.setOnClickListener {
            val go_to_reg= Intent(this, math_examActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up.setOnClickListener {
            val go_to_reg= Intent(this, cpp_examActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up5.setOnClickListener {
            val go_to_reg= Intent(this, python_examActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up6.setOnClickListener {
            val go_to_reg= Intent(this, java_examActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up7.setOnClickListener {
            val go_to_reg= Intent(this, geo_examActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up8.setOnClickListener {
            val go_to_reg= Intent(this, rus_examActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up9.setOnClickListener {
            val go_to_reg= Intent(this, kaz_examActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}