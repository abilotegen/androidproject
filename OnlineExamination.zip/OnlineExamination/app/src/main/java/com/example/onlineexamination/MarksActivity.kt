package com.example.onlineexamination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_marks.*

class MarksActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val context = this
        val db = DBHelper(context)
        sharedPreferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
        setContentView(R.layout.activity_marks)
        textView6.setText(db.readMath( sharedPreferences.getString("username", "").toString()))
        textView20.setText(db.readCPP( sharedPreferences.getString("username", "").toString()))
        textView22.setText(db.readPython( sharedPreferences.getString("username", "").toString()))
        textView24.setText(db.readJava( sharedPreferences.getString("username", "").toString()))
        textView26.setText(db.readGEO( sharedPreferences.getString("username", "").toString()))
        textView28.setText(db.readKAZ( sharedPreferences.getString("username", "").toString()))
        textView30.setText(db.readRUS( sharedPreferences.getString("username", "").toString()))

        sign_up4.setOnClickListener {
            val go_to_reg= Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}