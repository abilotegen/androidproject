package com.example.onlineexamination

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.kaz_edu.*

class kazActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kaz_edu)
        imageView2.setOnClickListener {
            val go_to_reg= Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
        start_btn.setOnClickListener {
            val go_to_reg= Intent(this, kaz_examActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}