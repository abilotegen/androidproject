package com.example.onlineexamination

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.cpp_edu.*

class cpp_matActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cpp_edu)
        imageView2.setOnClickListener {
            val go_to_reg= Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
        start_btn.setOnClickListener {
            val go_to_reg= Intent(this, cpp_examActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}