package com.example.onlineexamination

class User (Fullname: String, UserName: String, Email: String,  Phone: String,  Password: String) {
    var fullname = Fullname
    var username = UserName
    val phone = Phone
    var password = Password
    var email = Email
    var id=0
}