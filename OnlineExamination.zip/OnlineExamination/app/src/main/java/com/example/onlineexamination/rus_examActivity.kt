package com.example.onlineexamination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.rus_exam.*

class rus_examActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.rus_exam)
        imageView2.setOnClickListener {
            val go_to_reg= Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
        sharedPreferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
        val context = this
        val db = DBHelper(context)
        start_btn.setOnClickListener {
            val point1 = radioButton.isChecked
            val point2 = radioButton4.isChecked
            if(point1 && point2){
                db.updateRUS("100", sharedPreferences.getString("username", "").toString())
            } else if (point1 || point2){
                db.updateRUS("50", sharedPreferences.getString("username", "").toString())
            } else{
                db.updateRUS("0", sharedPreferences.getString("username", "").toString())
            }
            val go_to_reg= Intent(this, MarksActivity::class.java)
            startActivity(go_to_reg)

        }

    }
}