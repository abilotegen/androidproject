package com.example.onlineexamination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_menu.*
import kotlinx.android.synthetic.main.activity_menu.sign_up
import kotlinx.android.synthetic.main.activity_menu.start_btn

class MenuActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        sharedPreferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
        start_btn.setOnClickListener {
            val go_to_reg= Intent(this, ProfileActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up.setOnClickListener {
            val go_to_reg= Intent(this, MaterialActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up2.setOnClickListener {
            val go_to_reg= Intent(this, ExamActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up3.setOnClickListener {
            val go_to_reg= Intent(this, MarksActivity::class.java)
            startActivity(go_to_reg)
        }

        sign_up4.setOnClickListener {
            val editor: SharedPreferences.Editor = sharedPreferences.edit()
            editor.putString("username", "NULL")
            editor.apply()
            val go_to_reg= Intent(this, MainActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}