package com.example.onlineexamination

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

val DATABASENAME = "MY_DB"
val TABLENAME = "Userses"
val COL_FULLNAME = "fullname"
val COL_USERNAME = "username"
val COL_EMAIL = "email"
val COL_PHONE = "phones"
val COL_MATH = "math"
val COL_CPP = "cpp"
val COL_PYTHON = "python"
val COL_JAVA = "java"
val COL_GEO = "geog"
val COL_KAZ = "kazakh"
val COL_RUS = "russian"
val COL_PASSWORD = "password"
val COL_ID = "id"
class DBHelper (var context: Context) : SQLiteOpenHelper(context, DATABASENAME, null,
    1) {

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = "CREATE TABLE " + TABLENAME + " (" + COL_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_FULLNAME +
                " text, "+ COL_USERNAME + " text, " + COL_EMAIL + " text, " + COL_PHONE + " text, " + COL_MATH + " text, " + COL_CPP + " text, " + COL_PYTHON + " text, " +
                COL_JAVA + " text, " + COL_GEO + " text, " + COL_KAZ + " text, " + COL_RUS + " text, " + COL_PASSWORD + " text)"
        db?.execSQL(createTable)
    }
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }
    fun insertData(user: User) {

        val database = this.writableDatabase
        val contentValues = ContentValues()

        contentValues.put(COL_FULLNAME, "")
        contentValues.put(COL_USERNAME, user.username)
        contentValues.put(COL_EMAIL, "")
        contentValues.put(COL_PHONE, "")
        contentValues.put(COL_MATH, "")
        contentValues.put(COL_CPP, "")
        contentValues.put(COL_PYTHON, "")
        contentValues.put(COL_JAVA, "")
        contentValues.put(COL_GEO, "")
        contentValues.put(COL_KAZ, "")
        contentValues.put(COL_RUS, "")
        contentValues.put(COL_PASSWORD, user.password)
        Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show()
        val result = database.insert(TABLENAME, null, contentValues)
        if (result == (0).toLong()) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show()
        }
    }

    fun updatePassword(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_PASSWORD, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }

    fun updatePhone(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_PHONE, pass)

        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }

    fun updateEmail(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_EMAIL, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    fun updateFullname(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_FULLNAME, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }

    fun updateMath(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_MATH, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    fun updateCPP(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_CPP, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    fun updatePython(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_PYTHON, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))


    }

    fun updateJava(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_JAVA, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    fun updateGEO(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_GEO, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    fun updateKAZ(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_KAZ, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    fun updateRUS(pass: String, username: String) {

        val database = this.writableDatabase
        val contentValues = ContentValues()


        contentValues.put(COL_RUS, pass)
        database.update(TABLENAME,  contentValues, "username =? " , arrayOf(username))

    }
    @SuppressLint("Recycle")
    fun readPassword(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_PASSWORD))
        }
        result.close()
        return st
    }
    fun readEmail(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_EMAIL))
        }
        result.close()
        return st
    }
    fun readPhone(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_PHONE))
        }
        result.close()
        return st
    }
    fun readFullname(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_FULLNAME))
        }
        result.close()
        return st
    }
    fun readMath(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_MATH))
        }
        result.close()
        return st
    }
    fun readCPP(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_CPP))
        }
        result.close()
        return st
    }
    fun readPython(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_PYTHON))
        }
        result.close()
        return st
    }
    fun readJava(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_JAVA))
        }
        result.close()
        return st
    }
    fun readGEO(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_GEO))
        }
        result.close()
        return st
    }
    fun readKAZ(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_KAZ))
        }
        result.close()
        return st
    }
    fun readRUS(username: String): String {
        val db = this.readableDatabase
        var st = ""
        val query = "Select * from " + TABLENAME + " where " + COL_USERNAME + " = \'" + username+"\'"
        val result = db.rawQuery(query, null)
        if (result.moveToFirst()) {
            st=result.getString(result.getColumnIndex(COL_RUS))
        }
        result.close()
        return st
    }
}