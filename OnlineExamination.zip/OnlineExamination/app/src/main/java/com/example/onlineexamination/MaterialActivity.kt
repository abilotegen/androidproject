package com.example.onlineexamination

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_material.*

class MaterialActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_material)
        imageView2.setOnClickListener {
            val go_to_reg= Intent(this, MenuActivity::class.java)
            startActivity(go_to_reg)
        }
        start_btn.setOnClickListener {
            val go_to_reg= Intent(this, math_matActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up.setOnClickListener {
            val go_to_reg= Intent(this, cpp_matActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up5.setOnClickListener {
            val go_to_reg= Intent(this, python_matActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up6.setOnClickListener {
            val go_to_reg= Intent(this, java_matActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up7.setOnClickListener {
            val go_to_reg= Intent(this, geo_matActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up8.setOnClickListener {
            val go_to_reg= Intent(this, rus_matActivity::class.java)
            startActivity(go_to_reg)
        }
        sign_up9.setOnClickListener {
            val go_to_reg= Intent(this, kazActivity::class.java)
            startActivity(go_to_reg)
        }
    }
}