package com.example.onlineexamination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        imageView2.setOnClickListener{
            val go_to_reg= Intent(this, MainActivity::class.java)
            startActivity(go_to_reg)
        }

        sharedPreferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
        val context = this
        val db = DBHelper(context)
        sign_up.setOnClickListener {


            if(usr_input.text.toString().isNotEmpty() && password_input.text.toString().isNotEmpty()) {
                var user =User("", usr_input.text.toString(), "", "", password_input.text.toString())

                db.insertData(user)
                val editor: SharedPreferences.Editor = sharedPreferences.edit()
                editor.putString("username", usr_input.text.toString())
                editor.apply()
                val go_to_reg = Intent(this, MenuActivity::class.java)
                startActivity(go_to_reg)
            } else{
                Toast.makeText(context, "Incorrect", Toast.LENGTH_SHORT).show()
            }
        }
        start_btn.setOnClickListener {
            var passw = db.readPassword(usr_input.text.toString())
            if (passw == password_input.text.toString()){
                val editor: SharedPreferences.Editor = sharedPreferences.edit()
                editor.putString("username", usr_input.text.toString())
                editor.apply()
                val go_to_reg = Intent(this, MenuActivity::class.java)
                startActivity(go_to_reg)
            } else{
                Toast.makeText(context, "Incorrect", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

/*
*/